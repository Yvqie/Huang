import ee
ee.Authenticate()
ee.Initialize(project='ee-2171568961')
print("Authenticated and initialized")
